# Rchat — pack de pages unifié

Ce pack ajoute une couche de design commune aux pages HTML fournies, sans remplacer leurs scripts métier ni leurs connexions existantes.

## Pages incluses
- index.html — accueil / Hub
- chat.html — salon général (interface d’aperçu)
- evenements.html — évènements et aperçu QCM
- profil.html — profil
- ia.html — Rchat IA
- defis.html — défis
- ia 2.html — formulaire/ancienne page de consultation
- conversations.html — CODE CHAT
- premium.html — Rchat+
- administrateur.html — administration

## Fichiers communs ajoutés
- `rchat-global.css` : palette, surfaces, navigation, contrôles, responsive et préférences de mouvement.
- `rchat-global.js` : état actif du menu, navigation accessible et micro-interactions non bloquantes.

## Points à compléter
Les pages `chat.html` et `evenements.html` ont été créées dans le même design system. Elles fonctionnent en aperçu local. Le chat partagé, l’authentification, la publication d’évènements et l’enregistrement des QCM restent à raccorder aux tables et fonctions Supabase exactes. Le fichier `rchat-4.css` n’était pas fourni ; les pages utilisent `rchat-global.css`.

## Mise en ligne
Conserver les fichiers HTML à la racine du même dossier que `rchat-global.css` et `rchat-global.js`. Ne pas déplacer ces deux fichiers communs dans un sous-dossier sans modifier les chemins des balises `<link>` et `<script>`.

Les scripts et appels Supabase d'origine sont conservés. Tester les parcours d'authentification, les formulaires et les actions d'administration après déploiement.


## Configuration Supabase

Le projet Supabase configuré dans les pages existantes est `https://iqqllfcwdisomsyypeuu.supabase.co`, avec la clé publique `sb_publishable_…`. La page `ia 2.html` utilise maintenant ces mêmes paramètres pour sa table `rchat_qcm_reponses`.

**Important :** la clé publishable est prévue pour le navigateur, mais elle ne remplace pas les règles RLS. N'ajoute jamais une clé `sb_secret_…` ou `service_role` dans les fichiers HTML. Les pages `chat.html` et `evenements.html` restent des interfaces d'aperçu : les schémas exacts des tables du salon et des évènements ne sont pas présents dans ce pack, donc aucune écriture arbitraire n'a été inventée.
